import React, { useEffect, useState } from 'react';
import { Link, useLoaderData, useNavigate } from 'react-router-dom';
import foodImg from '../assets/foodRecipe.png';
import { BsStopwatchFill } from "react-icons/bs";
import { FaHeart } from "react-icons/fa6";
import { FaEdit } from "react-icons/fa";
import { MdDelete } from "react-icons/md";
import axios from 'axios';

export default function RecipeItems() {
  const recipes = useLoaderData();
  const [allRecipes, setAllRecipes] = useState();
  let path = window.location.pathname === "/myRecipe" ? true : false;
  let favItems = JSON.parse(localStorage.getItem("fav")) ?? [];
  const [isFavRecipe, setIsFavRecipe] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    setAllRecipes(recipes);
  }, [recipes]);

  const onDelete = async (id) => {
    await axios.delete(`http://localhost:8080/recipe/${id}`)
      .then((res) => console.log(res));
    setAllRecipes(recipes => recipes.filter(recipe => recipe.id !== id));
    let filterItem = favItems.filter(recipe => recipe.id !== id);
    localStorage.setItem("fav", JSON.stringify(filterItem));
  }

  const favRecipe = (item) => {
    let filterItem = favItems.filter(recipe => recipe.id !== item.id);
    favItems = favItems.filter(recipe => recipe.id === item.id).length === 0 ? [...favItems, item] : filterItem;
    localStorage.setItem("fav", JSON.stringify(favItems));
    setIsFavRecipe(pre => !pre);
  }

  return (
    <>
      <div className='card-container'>
        {
          allRecipes?.map((item, index) => {
            return (
              <div key={index} className='card' onDoubleClick={() => navigate(`/recipe/${item.id}`)}>
                <img src={`http://localhost:8080/images/${item.coverImage}`} width="120px" height="100px"></img>
                <div className='card-body'>
                  <div className='title'>{item.title}</div>
                  <div className='icons'>
                    <div className='timer'><BsStopwatchFill />{item.time}</div>
                    {(!path) ? <FaHeart onClick={() => favRecipe(item)}
                      style={{ color: (favItems.some(res => res.id === item.id)) ? "red" : "" }} /> :
                      <div className='action'>
                        <Link to={`/editRecipe/${item.id}`} className="editIcon"><FaEdit /></Link>
                        <MdDelete onClick={() => onDelete(item.id)} className='deleteIcon' />
                      </div>
                    }
                  </div>
                </div>
              </div>
            )
          })
        }
      </div>
    </>
  )
}

// import React from 'react'
// import { createBrowserRouter, RouterProvider } from 'react-router-dom'
// import Home from './pages/Home'
// import RecipeDetails from './pages/RecipeDetails'
// import AddFoodRecipe from './pages/AddFoodRecipe'
// import EditRecipe from './pages/editRecipe'
// import MainNavigation from './components/MainNavigation'
// import axios from 'axios'

// // Creating routes for the application
// const router = createBrowserRouter([
//   {
//     path: "/",
//     element: <MainNavigation />,
//     children: [
//       {
//         path: "/",
//         element: <Home />,
//         loader: async () => {
//           // Fetch all recipes from the backend (JSON storage)
//           return axios.get("http://localhost:8080/recipes")
//             .then(response => response.data)
//             .catch(error => console.error("Error fetching recipes:", error));
//         }
//       },
//       {
//         path: "/recipe/:id",
//         element: <RecipeDetails />,
//         loader: async ({ params }) => {
//           // Fetch a specific recipe by ID from the backend (JSON storage)
//           return axios.get(`http://localhost:5000/recipe/${params.id}`)
//             .then(response => response.data)
//             .catch(error => console.error("Error fetching recipe details:", error));
//         }
//       },
//       {
//         path: "/addRecipe",
//         element: <AddFoodRecipe />,
//       },
//       {
//         path: "/editRecipe/:id",
//         element: <EditRecipe />,
//         loader: async ({ params }) => {
//           // Fetch recipe data for editing from the backend (JSON storage)
//           return axios.get(`http://localhost:5000/recipe/${params.id}`)
//             .then(response => response.data)
//             .catch(error => console.error("Error fetching recipe for editing:", error));
//         }
//       },
//       {
//         path: "/myRecipe",
//         element: <Home />, // Use the Home component to list recipes
//         loader: async () => {
//           // Fetch recipes that belong to the logged-in user
//           const token = localStorage.getItem("token");
//           return axios.get("http://localhost:5000/myRecipes", {
//             headers: {
//               'authorization': `bearer ${token}`
//             }
//           })
//             .then(response => response.data)
//             .catch(error => console.error("Error fetching user's recipes:", error));
//         }
//       },
//       {
//         path: "/favRecipe",
//         element: <Home />, // Use the Home component to list favorite recipes
//         loader: async () => {
//           const favRecipes = JSON.parse(localStorage.getItem("fav")) || [];
//           return favRecipes;
//         }
//       }
//     ]
//   }
// ]);

// export default function App() {
//   return (
//     <RouterProvider router={router} />
//   )
// }








import React from 'react'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import Home from './pages/Home'
import RecipeDetails from './pages/RecipeDetails'
import AddFoodRecipe from './pages/AddFoodRecipe'
import EditRecipe from './pages/editRecipe'
import MainNavigation from './components/MainNavigation'
import axios from 'axios'

// Creating routes for the application
const router = createBrowserRouter([
  {
    path: "/",
    element: <MainNavigation />,
    children: [
      {
        path: "/",
        element: <Home />,
        loader: async () => {
          try {
            const response = await axios.get("http://localhost:8080/recipes");
            return response.data;
          } catch (error) {
            console.error("Error fetching recipes:", error);
            return []; // Return an empty array or handle the error appropriately
          }
        }
      },
      {
        path: "/recipe/:id",
        element: <RecipeDetails />,
        loader: async ({ params }) => {
          try {
            const response = await axios.get(`http://localhost:8080/recipe/${params.id}`);
            return response.data;
          } catch (error) {
            console.error("Error fetching recipe details:", error);
            return null; // Return null or handle the error appropriately
          }
        }
      },
      {
        path: "/addRecipe",
        element: <AddFoodRecipe />,
      },
      {
        path: "/editRecipe/:id",
        element: <EditRecipe />,
        loader: async ({ params }) => {
          try {
            const response = await axios.get(`http://localhost:8080/recipe/${params.id}`);
            return response.data;
          } catch (error) {
            console.error("Error fetching recipe for editing:", error);
            return null; // Return null or handle the error appropriately
          }
        }
      },
      {
        path: "/myRecipe",
        element: <Home />, // Use the Home component to list recipes
        loader: async () => {
          const token = localStorage.getItem("token");
          try {
            const response = await axios.get("http://localhost:8080/myRecipes", {
              headers: {
                'authorization': `bearer ${token}`
              }
            });
            return response.data;
          } catch (error) {
            console.error("Error fetching user's recipes:", error);
            return []; // Return an empty array or handle the error appropriately
          }
        }
      },
      {
        path: "/favRecipe",
        element: <Home />, // Use the Home component to list favorite recipes
        loader: async () => {
          try {
            const favRecipes = JSON.parse(localStorage.getItem("fav")) || [];
            return favRecipes;
          } catch (error) {
            console.error("Error fetching favorite recipes:", error);
            return []; // Return an empty array or handle the error appropriately
          }
        }
      }
    ]
  }
]);

export default function App() {
  return (
    <RouterProvider router={router} />
  )
}

